﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MechanicChecker.Models
{
    public class EFLocalProductRepository : ILocalProductRepository
    {   

        private ApplicationDbContext context;
        public EFLocalProductRepository(ApplicationDbContext ctx)
        {
            context = ctx;
        }
        //public IQueryable<LocalProduct> LocalProducts => context.LocalProduct;

    }
}
