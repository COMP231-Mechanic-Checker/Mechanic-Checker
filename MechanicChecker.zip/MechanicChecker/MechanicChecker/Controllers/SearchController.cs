﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MechanicChecker.Models;
using Microsoft.AspNetCore.Mvc;

namespace MechanicChecker.Controllers
{
    public class SearchController : Controller
    {
        //private ILocalProductRepository repository;

        //public SearchController(ILocalProductRepository repo)
        //{
        //    repo = repository;
        //}

        public IActionResult Index()
        {
            LocalProductContext context = HttpContext.RequestServices.GetService(typeof(MechanicChecker.Models.LocalProductContext)) as LocalProductContext;

            return View(context.GetAllProducts());
        }

        public ViewResult Search(String query) // the value gotten from the url
        {
            query = "tire";
            LocalProductContext context = HttpContext.RequestServices.GetService(typeof(MechanicChecker.Models.LocalProductContext)) as LocalProductContext;

            var allProducts = context.GetAllProducts();

            var listOfQueriedProducts = allProducts.Where(
                product =>
                product.Title.Contains(query) || product.Description.Contains(query)
                );


            //Dummy data just to display products on SearchResultsList.cshtml
            //LocalProduct SingleProduct = new LocalProduct()
            //{
            //    Description = "This works",
            //    Price = "21",
            //    Title = "Tires",
            //    Visibility = true,
            //    sellerId = "1",
            //    ImageUrl = "nill"
            //};

            //List<LocalProduct> products = new List<LocalProduct>();
            //products.Add(SingleProduct);
            return View("SearchResultsList", listOfQueriedProducts);
        }
    }
}
