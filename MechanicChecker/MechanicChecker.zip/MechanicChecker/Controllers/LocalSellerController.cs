﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MechanicChecker.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace MechanicChecker.Controllers
{
    public class LocalSellerController : Controller
    {
        //global variables for the list of all the products belonging to the seller, and context
        private List<SellerProduct> currentSellerProducts = new List<SellerProduct>();
        private SellerProductContext context;

        // GET: LocalSellerController
        public ActionResult Index(string userName)
        {

            SellerProductContext sellerProductContext = HttpContext.RequestServices.GetService(typeof(MechanicChecker.Models.SellerProductContext)) as SellerProductContext;
            SellerContext sellerContext = HttpContext.RequestServices.GetService(typeof(MechanicChecker.Models.SellerContext)) as SellerContext;

            Seller seller = sellerContext.GetSeller(userName);
            var allSellerProducts = sellerProductContext.GetAllSellerProducts();
            var sellerProducts = allSellerProducts.Where(p => p.seller.UserName.Equals(seller.UserName));
            return View("../LocalSeller/SellerLandingPage", sellerProducts);
        }



        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SearchProducts(string username, string keyword)
        {
            try
            {

                context = HttpContext.RequestServices.GetService(typeof(MechanicChecker.Models.SellerProductContext)) as SellerProductContext;
                currentSellerProducts = (List<SellerProduct>)context.GetAllSellerProducts();
                IEnumerable<SellerProduct> searchedSellerProducts = new List<SellerProduct>();
                if (keyword != null)
                {
                    searchedSellerProducts = currentSellerProducts.Where(
                       product =>
                       (product.localProduct.Title.Contains(keyword, StringComparison.OrdinalIgnoreCase) || product.localProduct.Description.Contains(keyword, StringComparison.OrdinalIgnoreCase))
                            && product.seller.UserName.Equals(username)
                       );
                }
                else
                {
                    searchedSellerProducts = currentSellerProducts;                
                }
                return View("SellerLandingPage", searchedSellerProducts);
            }
            catch
            {
                return View("SellerLandingPage", currentSellerProducts);
            }
        }


        // GET: LocalSellerController/Details/5
        public ActionResult Details(int id, string sellerID)
        {
            context = HttpContext.RequestServices.GetService(typeof(MechanicChecker.Models.SellerProductContext)) as SellerProductContext;
            currentSellerProducts = (List<SellerProduct>)context.GetAllSellerProducts();
            IEnumerable<SellerProduct> searchedSellerProducts = new List<SellerProduct>();
            if(currentSellerProducts.Count() > 0) 
            {
                
                //searchedSellerProducts = currentSellerProducts ;
                searchedSellerProducts = currentSellerProducts.Where(
                   product =>
                   product.localProduct.LocalProductId == id&& product.localProduct.sellerId == sellerID
                   );
                ViewBag.CurrentSeller = searchedSellerProducts.FirstOrDefault().seller.UserName;
                return View("Details", searchedSellerProducts.FirstOrDefault().localProduct);
            }
            else
            {
                return View("SellerLandingPage", searchedSellerProducts);
            }          
            
        }

        // GET: LocalSellerController/Create
        public ActionResult Create(int id, string sellerID)
        {
            context = HttpContext.RequestServices.GetService(typeof(MechanicChecker.Models.SellerProductContext)) as SellerProductContext;
            currentSellerProducts = (List<SellerProduct>)context.GetAllSellerProducts();
            ViewBag.CurrentSeller = currentSellerProducts.FirstOrDefault().seller.UserName;
            return View("Create");
        }

        // POST: LocalSellerController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return View("Create");
            }
            catch
            {
                return View();
            }
        }

        // GET: LocalSellerController/Edit/5
        public ActionResult Edit(int id, string sellerID)
        {
            context = HttpContext.RequestServices.GetService(typeof(MechanicChecker.Models.SellerProductContext)) as SellerProductContext;
            currentSellerProducts = (List<SellerProduct>)context.GetAllSellerProducts();
            IEnumerable<SellerProduct> searchedSellerProducts = new List<SellerProduct>();
            if (currentSellerProducts.Count() > 0)
            {
                //searchedSellerProducts = currentSellerProducts ;
                searchedSellerProducts = currentSellerProducts.Where(
                   product =>
                   product.localProduct.LocalProductId == id && product.localProduct.sellerId == sellerID
                   );
                ViewBag.CurrentSeller = searchedSellerProducts.FirstOrDefault().seller.UserName;
                return View("Edit", searchedSellerProducts.FirstOrDefault().localProduct);
            }
            else
            {
                return View("SellerLandingPage", searchedSellerProducts);
            }
        }

        // POST: LocalSellerController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: LocalSellerController/Delete/5
        public ActionResult Delete(int id, string sellerID)
        {
            context = HttpContext.RequestServices.GetService(typeof(MechanicChecker.Models.SellerProductContext)) as SellerProductContext;
            currentSellerProducts = (List<SellerProduct>)context.GetAllSellerProducts();
            IEnumerable<SellerProduct> searchedSellerProducts = new List<SellerProduct>();
            if (currentSellerProducts.Count() > 0)
            {
                //searchedSellerProducts = currentSellerProducts ;
                searchedSellerProducts = currentSellerProducts.Where(
                   product =>
                   product.localProduct.LocalProductId == id && product.localProduct.sellerId == sellerID
                   );
                ViewBag.CurrentSeller = searchedSellerProducts.FirstOrDefault().seller.UserName;
                return View("Delete", searchedSellerProducts.FirstOrDefault().localProduct);
            }
            else
            {
                return View("SellerLandingPage", searchedSellerProducts);
            }
        }

        // POST: LocalSellerController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
